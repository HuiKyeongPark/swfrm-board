package board.exception;

//입력받은 비밀번호와 저장된 비밀번호가 일치하지 않은 예외처리
public class WrongIdPasswordException extends RuntimeException {
}
