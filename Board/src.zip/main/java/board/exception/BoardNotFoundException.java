package board.exception;

//존재하지 않는 게시물 예외처리
public class BoardNotFoundException extends RuntimeException {

}
